<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
	<link rel="stylesheet" href="css/style.css">
	<style>
		input[type="radio"] {
			display: none;
		}

		label {
			text-align: center;
			display: inline-block;
			width: 20px;
			height: 20px;
			border: 1px solid;
		}
		label:hover {
			background-color: red;
		}

		#pluz:checked ~ #lable-1 {  
		  color: red;
		}
		#minus:checked ~ #lable-2 {  
		  color: red;
		}
		#ymn:checked ~ #lable-3 {  
		  color: red;
		}
		#del:checked ~ #lable-4 {  
		  color: red;
		}

	</style>
</head>
<body>


<form method="POST" name="upload">
	<input type="text" name="num-1" placeholder="Первое число">
	
	<input id="pluz" name="oper" type="radio" value="+">
	<label id="lable-1" for="pluz">+</label>

	<input id="minus" name="oper" type="radio" value="-">
	<label id="lable-2" for="minus">-</label>

	<input id="ymn"name="oper" type="radio" value="*">
	<label id="lable-3" for="ymn">*</label>

	<input id="del" name="oper" type="radio" value="/">
	<label id="lable-4" for="del">/</label> 

	<input type="text" name="num-2" placeholder="Второе число">
	<input id="button" type="submit" value="Посчитать">
</form>
	<ul id="list"></ul>

  <script>
  	
    document.forms.upload.onsubmit = function() {

    
    var num_1 = document.getElementsByName('num-1')[0].value;
    var znak = document.getElementsByName('oper');
    for (var i = 0; i < 3; i++) {
    	if (znak[i].checked ==true ) {
    	var oper = znak[i].value;
    	}
    }
    var num_2 = document.getElementsByName('num-2')[0].value;
      var xhr = new XMLHttpRequest();
      var params = 'num-1=' + encodeURIComponent(num_1) +
  		'&num-2=' + encodeURIComponent(num_2) + '&oper=' + encodeURIComponent(oper);

      xhr.open('GET', 'calc.php?' + params, true);
      xhr.send();
      xhr.onreadystatechange = function() {
      	if (xhr.readyState != 4) return;
      	button.innerHTML = 'Готово!'

      	if (xhr.status != 200) {
   			 alert(xhr.status + ': ' + xhr.statusText);
  		} else {
  			var li = list.appendChild(document.createElement('li'));
        	li.innerHTML = xhr.responseText;
  		}

     }
      return false;
  }


  
  </script>
	
</body>
</html>


