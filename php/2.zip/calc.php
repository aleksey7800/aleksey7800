<?php
	$num_1 = $_GET['num-1'];
	$oper = $_GET['oper'];
	$num_2 = $_GET['num-2'];
	if ($oper == '+') {
		echo $x = $num_1 + $num_2;
	} elseif ($oper == '-') {
		echo $x = $num_1 - $num_2;
	} elseif ($oper == '*') {
		echo $x = $num_1 * $num_2;
	} elseif ($oper == '/') {
		if ($num_2 == 0) {
			echo "На 0 делить нельзя";
		} else {
			echo $x = $num_1 / $num_2;
		}
		
	}
	
?>