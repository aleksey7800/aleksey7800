<?php
	include 'connekt.php';
	$id = $_GET["id"];
	$query = "SELECT * FROM Tovari WHERE idTovari = '{$id}'";

	$result = mysqli_query($link, $query) or die(mysqli_error($link));

	for ($data = []; $row = mysqli_fetch_assoc($result); $data[] = $row); 
		echo 'Название товара - ' . $data[0]['Name'] . '<br>' . 'Описание товара - ' . $data[0]['title'] . '<br> Цена товар -  ' . $data[0]['price'] . '<br><img src="img/lardge/' . $data[0]['img'] . '" alt="">' . '<br><hr>';
	
	
?>