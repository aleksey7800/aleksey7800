
<?php 
		function goback()
         {
             header("Location: {$_SERVER['HTTP_REFERER']}");
             exit;
         }

	include 'connekt.php';
	$id = $_GET["id"];
	$act = $_GET["action"];


	if ($act == add) {
		echo '<form action="" method="GET">';
		echo '<p>Название</p><input type="text" name="Name-1" value="">
			<p>Описание</p><input type="text" name="Text" value=""><br>
			<p>Цена</p><input type="text" name="Price" value=""><br>
			<p>Картинка</p><input type="text" name="img" value=""><br>';	
		echo '<input type="submit"></form>';

	} elseif ($act == cheng) {
		echo '<form action="" method="GET">';

		$query = "SELECT * FROM Tovari WHERE idTovari = '{$id}'";

		$result = mysqli_query($link, $query) or die(mysqli_error($link));

		for ($data = []; $row = mysqli_fetch_assoc($result); $data[] = $row); 
			echo '<form action="" method="GET">';
			echo '<input type="hidden" name="id" value="'. $data[0]['idTovari'] .'">
			<p>Название</p><input type="text" name="Name-2" value="'. $data[0]['Name'] .'"><br>
				<p>Описание</p><input type="text" name="Text" value="' . $data[0]['title'] . '"><br>
				<p>Цена</p><input type="text" name="Price" value="' . $data[0]['price'] . '"><br>
				<p>Картинка</p><input type="text" name="img" value="' . $data[0]['img'] . '"><br>';	
			echo '<input type="submit"></form>';

	} elseif ($act == delete) {
		$query = "DELETE FROM Tovari WHERE idTovari = '{$id}'";
		$result = mysqli_query($link, $query) or die(mysqli_error($link));
         goback();
	};

	$id = $_GET["id"];
	$Name_1 = $_GET['Name-1'];
	$Name_2 = $_GET['Name-2'];
	$Text = $_GET['Text'];
	$Price = $_GET['Price'];
	$img = $_GET['img'];

	if (isset($Name_1)) {
		$query = "INSERT INTO Tovari SET Name='{$Name_1}', title='{$Text}', price='{$Price}', img='{$img}'";
		$result = mysqli_query($link, $query) or die(mysqli_error($link));
		goback();
	} elseif (isset($Name_2)) {
		 $query2 = "UPDATE Tovari SET Name='{$Name_2}',title='{$Text}',price='{$Price}', img='{$img}' WHERE idTovari = '{$id}'";
 		$result2 = mysqli_query($link, $query2) or die(mysqli_error($link));
 		goback();
	}


?>





