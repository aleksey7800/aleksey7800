
 <?php
 	include 'connekt.php';
 	$id = 2/*$_GET["id"]*/;
	$name = $_GET['Name'];
	$title = $_GET['Text'];
	$price = $_GET['Price'];

 	$query2 = "UPDATE Tovari SET Name='{$name}',title='{$title}',price='{$price}' WHERE idTovari = '{$id}'";
 	$result2 = mysqli_query($link, $query2) or die(mysqli_error($link));
?>