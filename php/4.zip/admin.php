<?php
	include 'connekt.php';

	$query = "SELECT * FROM Tovari WHERE idTovari > 0";

	$result = mysqli_query($link, $query) or die(mysqli_error($link));

	for ($data = []; $row = mysqli_fetch_assoc($result); $data[] = $row); 
			for ($i=0; $i < count($data); $i++) { 
				echo $data[$i]['Name'] . ' <a href="admin-2.php?id=' . $data[$i]['idTovari'] . '&action=cheng">Изменить</a>  <a href="admin-2.php?id=' . $data[$i]['idTovari'] . '&action=delete">Удалить</a><br><hr>';
			}
	
	
?>

<a href="admin-2.php?&action=add">Добавить товар</a>