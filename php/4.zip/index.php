<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
	<link rel="stylesheet" href="css/style.css">
	<style>


	</style>
</head>
<body>
	<?php 

		include 'calc.php';

	?>


<a href="admin.php">Адмминка</a>

	
</body>
</html>


