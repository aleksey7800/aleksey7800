<?php
	include 'connekt.php';

	$query = "SELECT * FROM Tovari WHERE idTovari > 0";

	$result = mysqli_query($link, $query) or die(mysqli_error($link));

	for ($data = []; $row = mysqli_fetch_assoc($result); $data[] = $row); 
			for ($i=0; $i < count($data); $i++) { 
				echo 'Название товара - ' . $data[$i]['Name'] . '<br>Описание товара - ' . $data[$i]['title'] . '<br>Цена товара - ' . $data[$i]['price'] . '<br><img src="img/smal/' . $data[$i]['img'] . '" alt=""> <br> <a href="tovar.php?id=' . $data[$i]['idTovari'] . '">Подробнее</a><br><hr>';
			}
	
	
?>