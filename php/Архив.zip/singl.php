<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
	<link rel="stylesheet" href="css/style.css">
</head>
<body>



	<div class="galereya-1">
<?php 

		$id = $_GET['id'];
		$host = 'localhost';
		$user = 'root';
		$password = 'root';
		$db_name = 'geek_dz_1';

		$link = mysqli_connect($host, $user, $password, $db_name);

		mysqli_query($link, "SET NAMES 'utf8'");

		$query = "SELECT * FROM test_1 WHERE id = $id";

		$result = mysqli_query($link, $query) or die(mysqli_error($link));

		for ($data = []; $row = mysqli_fetch_assoc($result); $data[] = $row);
			$kol_vo = $data[0]["kol_vo"];
			$kol_vo++;
			$query2 = "UPDATE test_1 SET kol_vo = '{$kol_vo}' WHERE id = '{$id}'";
			$result2 = mysqli_query($link, $query2) or die(mysqli_error($link));
			echo '<img src="img/lardge/' . $data[0]["img_lardge"] . '" alt=""><br>';
			echo "Количество просмотров - $kol_vo";

?>
	</div>
	<img src="" alt="">
</body>
</html>