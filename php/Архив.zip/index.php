<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
	<link rel="stylesheet" href="css/style.css">
</head>
<body>

	<div class="galereya">
<?php 

$dir = 'img/';
$files1 = scandir($dir);
array_shift($files1);
array_shift($files1);

	foreach ($files1 as $key => $value) {
		echo '<a href="img/' . $value . '"><img src="img/' . $value . '"alt=""></a>';
	};

?>
	</div>
	
</body>
</html>


