<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
	<link rel="stylesheet" href="css/style.css">
</head>
<body>



	<div class="galereya">
<?php 

		$host = 'localhost';
		$user = 'root';
		$password = 'root';
		$db_name = 'geek_dz_1';

		$link = mysqli_connect($host, $user, $password, $db_name);

		mysqli_query($link, "SET NAMES 'utf8'");

		$query = "SELECT * FROM test_1 WHERE id > 0 ORDER BY kol_vo DESC";

		$result = mysqli_query($link, $query) or die(mysqli_error($link));

		for ($data = []; $row = mysqli_fetch_assoc($result); $data[] = $row);
			for ($i=0; $i < count($data); $i++) { 
				echo '<a href="singl.php?id=' . $data[$i]["id"] . '"><img src="img/smal/' . $data[$i]["img_smol"] . '"alt=""></a>';
				
			}
			
/*	$dir = 'img/lardge/';
	$files1 = scandir($dir);
	array_shift($files1);
	array_shift($files1);
	$dir2 = 'img/smal/';
	$files2 = scandir($dir2);
	array_shift($files2);
	array_shift($files2);*/

?>
	</div>
	
</body>
</html>


