<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
	<link rel="stylesheet" href="css/style.css">
	<style>


	</style>
</head>
<body>
	<?php 
		include 'connekt.php';

	$link = mysqli_connect($host, $user, $password, $db_name);
	mysqli_query($link, "SET NAMES 'utf8'");
	?>


<form method="GET" action="calc.php">
	<p>Имя</p>
	<input type="text" name="name">
	<p>Отзывы</p>
	<textarea name="text" cols="30" rows="10"></textarea><br>
	<input type="submit" value="отправить">

</form>
	<?php
		$query = "SELECT * FROM otzivi WHERE id > 0";

		$result = mysqli_query($link, $query) or die(mysqli_error($link));

		for ($data = []; $row = mysqli_fetch_assoc($result); $data[] = $row); 
			for ($i=0; $i < count($data); $i++) { 
				echo $data[$i]['name'] . '<br>' . $data[$i]['otziv'] . '<br><hr>';
			}
	?>


	
</body>
</html>


