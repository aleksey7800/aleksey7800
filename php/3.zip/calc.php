<?php
	include 'connekt.php';

	$name = $_GET["name"];
	$text = $_GET["text"];

	$query = "INSERT INTO otzivi SET name='{$name}', otziv='{$text}'";

	$result = mysqli_query($link, $query) or die(mysqli_error($link));

	if (isset($result)) {
		echo "Успешно";
	}
	
?>