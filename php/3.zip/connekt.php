<?php
	$id = $_GET['id'];
	$host = 'localhost';
	$user = 'root';
	$password = 'root';
	$db_name = 'geek_dz_1';

	$link = mysqli_connect($host, $user, $password, $db_name);
	mysqli_query($link, "SET NAMES 'utf8'");
?>