<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
	<link rel="stylesheet" href="css/style.css">
</head>
<body>


<form method="POST" name="upload">
	<input type="text" name="num-1" placeholder="Первое число">
	<select size="1" name="oper">
	  <option value="+">+</option>
	  <option value="-">-</option>
	  <option value="*">*</option>
	  <option value="/">/</option>
	</select>
	<input type="text" name="num-2" placeholder="Второе число">
	<input id="button" type="submit" value="Посчитать">
</form>
	<ul id="list"></ul>

  <script>
  	
    document.forms.upload.onsubmit = function() {

    
    var num_1 = document.getElementsByName('num-1')[0].value;
    var oper = document.getElementsByName('oper')[0].value;
    var num_2 = document.getElementsByName('num-2')[0].value;
      var xhr = new XMLHttpRequest();
      var params = 'num-1=' + encodeURIComponent(num_1) +
  		'&num-2=' + encodeURIComponent(num_2) + '&oper=' + encodeURIComponent(oper);

      xhr.open('GET', 'calc.php?' + params, true);
      xhr.send();
      xhr.onreadystatechange = function() {
      	if (xhr.readyState != 4) return;
      	button.innerHTML = 'Готово!'

      	if (xhr.status != 200) {
   			 alert(xhr.status + ': ' + xhr.statusText);
  		} else {
  			var li = list.appendChild(document.createElement('li'));
        	li.innerHTML = xhr.responseText;
  		}

     }
      return false;
  }


  
  </script>
	
</body>
</html>


